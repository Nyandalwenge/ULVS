-- MySQL dump 10.13  Distrib 5.7.19, for Linux (x86_64)
--
-- Host: localhost    Database: DES
-- ------------------------------------------------------
-- Server version	5.7.19-0ubuntu0.17.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Candidate`
--

DROP TABLE IF EXISTS `Candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Candidate` (
  `Candidate_Reg_No` varchar(15) NOT NULL,
  `Candidate_Motor` text,
  `Position_Id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Candidate_Reg_No`),
  KEY `Position_Id` (`Position_Id`),
  CONSTRAINT `Candidate_ibfk_1` FOREIGN KEY (`Candidate_Reg_No`) REFERENCES `Student` (`Reg_No`),
  CONSTRAINT `Candidate_ibfk_2` FOREIGN KEY (`Position_Id`) REFERENCES `Leadership_Position` (`Position_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Candidate`
--

LOCK TABLES `Candidate` WRITE;
/*!40000 ALTER TABLE `Candidate` DISABLE KEYS */;
INSERT INTO `Candidate` VALUES ('2015-04-01020','Poor dady Rich dady',5),('2015-04-01040','Power for freedom',6),('2015-04-01141','I was meant to lead as president',1),('2015-04-01300','Education for libaration',5),('2015-04-01320','Good governance for better development',7),('2015-04-01540','Unity is power',2),('2015-04-01541','Good leadership for better developments',6),('2015-04-02078','Poor dady Rich dady',4),('2015-04-02178','Together we can',3),('2015-04-02341','I am not interested in being a leader, am interested in seeking developments',2),('2015-04-02371','Vote for John to welcome changes',1);
/*!40000 ALTER TABLE `Candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `College`
--

DROP TABLE IF EXISTS `College`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `College` (
  `College_Id` int(11) NOT NULL AUTO_INCREMENT,
  `CC_Id` int(11) DEFAULT NULL,
  `College_Name` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`College_Id`),
  KEY `CC_Id` (`CC_Id`),
  CONSTRAINT `College_ibfk_1` FOREIGN KEY (`CC_Id`) REFERENCES `College_Category` (`CC_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `College`
--

LOCK TABLES `College` WRITE;
/*!40000 ALTER TABLE `College` DISABLE KEYS */;
INSERT INTO `College` VALUES (1,1,'CoICT'),(2,1,'CoET'),(3,1,'CoNAS'),(4,3,'UDBS'),(5,1,'CoHU'),(6,1,'CoAFS'),(7,3,'UDSoL'),(8,2,'IKS'),(9,1,'CoSS'),(10,2,'IDS'),(11,2,'IRA'),(12,3,'UDSoHS'),(13,3,'SJMC'),(14,3,'SoED'),(15,2,'IMS');
/*!40000 ALTER TABLE `College` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `College_Category`
--

DROP TABLE IF EXISTS `College_Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `College_Category` (
  `CC_Id` int(11) NOT NULL AUTO_INCREMENT,
  `CC_Name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`CC_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `College_Category`
--

LOCK TABLES `College_Category` WRITE;
/*!40000 ALTER TABLE `College_Category` DISABLE KEYS */;
INSERT INTO `College_Category` VALUES (1,'College'),(2,'Institute'),(3,'School');
/*!40000 ALTER TABLE `College_Category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Course`
--

DROP TABLE IF EXISTS `Course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Course` (
  `Course_Id` int(11) NOT NULL AUTO_INCREMENT,
  `College_Id` int(11) DEFAULT NULL,
  `Course_Name` varchar(250) NOT NULL,
  PRIMARY KEY (`Course_Id`),
  KEY `College_Id` (`College_Id`),
  CONSTRAINT `Course_ibfk_1` FOREIGN KEY (`College_Id`) REFERENCES `College` (`College_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Course`
--

LOCK TABLES `Course` WRITE;
/*!40000 ALTER TABLE `Course` DISABLE KEYS */;
INSERT INTO `Course` VALUES (1,1,'Bsc In Computer Science'),(2,1,'Bsc with Computer Science'),(3,1,'Bsc In Computer Eng'),(4,1,'Bsc In Telecommunication Eng'),(5,1,'Bsc In Electronics Science'),(6,1,'Bsc In Civil Eng'),(7,1,'BA In Anthropology'),(8,1,'BA In Economics'),(9,1,'BA In Literature'),(10,3,'BA in Journalisim'),(11,3,'BA In Mass Communication'),(12,3,'BA In Public Relations And Advertising'),(13,2,'BA In Kiswahili'),(14,3,'Doctor Of Medicine');
/*!40000 ALTER TABLE `Course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Leadership_Position`
--

DROP TABLE IF EXISTS `Leadership_Position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Leadership_Position` (
  `Position_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Position_Name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Position_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Leadership_Position`
--

LOCK TABLES `Leadership_Position` WRITE;
/*!40000 ALTER TABLE `Leadership_Position` DISABLE KEYS */;
INSERT INTO `Leadership_Position` VALUES (1,'President'),(2,'Vice President'),(3,'College Chair Person'),(4,'College Secretary'),(5,'Male USRC'),(6,'Female USRC'),(7,'Resident Chair Person'),(8,'Resident Secretary');
/*!40000 ALTER TABLE `Leadership_Position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Phone`
--

DROP TABLE IF EXISTS `Phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Phone` (
  `Reg_No` varchar(15) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  PRIMARY KEY (`Reg_No`,`Phone`),
  CONSTRAINT `Phone_ibfk_1` FOREIGN KEY (`Reg_No`) REFERENCES `Student` (`Reg_No`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Phone`
--

LOCK TABLES `Phone` WRITE;
/*!40000 ALTER TABLE `Phone` DISABLE KEYS */;
INSERT INTO `Phone` VALUES ('2015-04-01020','0767438276'),('2015-04-01040','0745876542'),('2015-04-01141','0653546789'),('2015-04-01300','0756374889'),('2015-04-01320','0757634872'),('2015-04-01328','0735647839'),('2015-04-01540','0875342346'),('2015-04-01541','0754352768'),('2015-04-02020','0753623458'),('2015-04-02078','0637835092'),('2015-04-02178','0746752890'),('2015-04-02341','0716538729'),('2015-04-02371','0716765392'),('2015-04-02571','0673636564');
/*!40000 ALTER TABLE `Phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Residence`
--

DROP TABLE IF EXISTS `Residence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Residence` (
  `Resident_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Resident_Name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Resident_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Residence`
--

LOCK TABLES `Residence` WRITE;
/*!40000 ALTER TABLE `Residence` DISABLE KEYS */;
INSERT INTO `Residence` VALUES (1,'Mabibo-A'),(2,'Mabibo-B'),(3,'Mabibo-C'),(4,'Mabibo-D'),(5,'Mabibo-E'),(6,'Mabibo-F'),(7,'Campus H-1'),(8,'Campus H-2'),(9,'Campus H-3'),(10,'Campus H-4'),(11,'Campus H-5'),(12,'Campus H-6'),(13,'Campus H-7');
/*!40000 ALTER TABLE `Residence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Student`
--

DROP TABLE IF EXISTS `Student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Student` (
  `Reg_No` varchar(15) NOT NULL,
  `Year` int(5) DEFAULT NULL,
  `First_Name` varchar(20) DEFAULT NULL,
  `Middle_Name` varchar(20) DEFAULT NULL,
  `Last_Name` varchar(20) DEFAULT NULL,
  `Resident_Id` int(11) DEFAULT NULL,
  `Course_Id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Reg_No`),
  KEY `Resident_Id` (`Resident_Id`),
  KEY `Course_Id` (`Course_Id`),
  CONSTRAINT `Student_ibfk_1` FOREIGN KEY (`Resident_Id`) REFERENCES `Residence` (`Resident_Id`),
  CONSTRAINT `Student_ibfk_3` FOREIGN KEY (`Course_Id`) REFERENCES `Course` (`Course_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Student`
--

LOCK TABLES `Student` WRITE;
/*!40000 ALTER TABLE `Student` DISABLE KEYS */;
INSERT INTO `Student` VALUES ('2015-04-01020',3,'Anderson','Jakil','Rossio',1,4),('2015-04-01040',3,'Naj','Tariq','Agreyson',1,3),('2015-04-01141',2,'Daniel','Gibrial','Vaug',1,1),('2015-04-01300',3,'Benzoate','David','Jimmy',1,6),('2015-04-01320',3,'Hudson','David','Benedict',1,5),('2015-04-01328',3,'Dickson','David','Vanile',1,5),('2015-04-01540',3,'Trey','Chris','Robin',1,1),('2015-04-01541',3,'Diana','Anile','Gibson',1,1),('2015-04-02020',2,'Ludovic','David','Jimmy',1,6),('2015-04-02078',2,'Andrew','Grande','Justin',1,4),('2015-04-02178',2,'Andrew','Jonathan','Zipper',1,2),('2015-04-02341',2,'Samwel','Trish','Gustin',3,1),('2015-04-02371',2,'John','Damian','Grant',1,3),('2015-04-02571',2,'Yezileli','Yoram','Ilomo',NULL,NULL);
/*!40000 ALTER TABLE `Student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Vote`
--

DROP TABLE IF EXISTS `Vote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vote` (
  `Voter_Reg_No` varchar(15) NOT NULL,
  `Position_Id` int(11) NOT NULL,
  `Candidate_Reg_No` varchar(15) DEFAULT NULL,
  `Vote_Date` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`Voter_Reg_No`,`Position_Id`),
  KEY `Candidate_Reg_No` (`Candidate_Reg_No`),
  KEY `Position_Id` (`Position_Id`),
  CONSTRAINT `Vote_ibfk_1` FOREIGN KEY (`Candidate_Reg_No`) REFERENCES `Candidate` (`Candidate_Reg_No`),
  CONSTRAINT `Vote_ibfk_2` FOREIGN KEY (`Voter_Reg_No`) REFERENCES `Student` (`Reg_No`),
  CONSTRAINT `Vote_ibfk_3` FOREIGN KEY (`Position_Id`) REFERENCES `Candidate` (`Position_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Vote`
--

LOCK TABLES `Vote` WRITE;
/*!40000 ALTER TABLE `Vote` DISABLE KEYS */;
INSERT INTO `Vote` VALUES ('2015-04-01040',4,'2015-04-02078','2017-01-15 11:10:22.633'),('2015-04-01141',1,'2015-04-01141','2017-01-15 08:51:08.088'),('2015-04-01141',2,'2015-04-01141','2017-01-15 08:51:08.088'),('2015-04-02341',1,'2015-04-01141','2017-01-15 08:51:08.088'),('2015-04-02341',2,'2015-04-02341','2017-01-15 08:51:08.088'),('2015-04-02371',1,'2015-04-02371','2017-01-15 08:51:08.088'),('2015-04-02371',2,'2015-04-02341','2017-01-15 08:51:08.088'),('2015-04-02571',1,'2015-04-02371','2017-01-15 08:51:08.088'),('2015-04-02571',2,'2015-04-02341','2017-01-15 08:51:08.088');
/*!40000 ALTER TABLE `Vote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `Yezy`
--

DROP TABLE IF EXISTS `Yezy`;
/*!50001 DROP VIEW IF EXISTS `Yezy`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `Yezy` AS SELECT 
 1 AS `Reg_No`,
 1 AS `Year`,
 1 AS `First_Name`,
 1 AS `Middle_Name`,
 1 AS `Last_Name`,
 1 AS `Resident_Id`,
 1 AS `Course_Id`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `Yezy`
--

/*!50001 DROP VIEW IF EXISTS `Yezy`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Yezy` AS select `Student`.`Reg_No` AS `Reg_No`,`Student`.`Year` AS `Year`,`Student`.`First_Name` AS `First_Name`,`Student`.`Middle_Name` AS `Middle_Name`,`Student`.`Last_Name` AS `Last_Name`,`Student`.`Resident_Id` AS `Resident_Id`,`Student`.`Course_Id` AS `Course_Id` from `Student` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-25 12:49:08
